<template>
  <div class="container mx-auto py-8 text-center mt-16 bg-gradient-to-r from-blue-200 to-blue-100 rounded-lg shadow-lg">
    <h1 class="text-4xl font-bold mb-8 text-blue-700 text-center">To Do List</h1> 
    <TodoList />
  </div>
</template>

<script>
import TodoList from './components/TodoList.vue';

export default {
  components: {
    TodoList
  }
}
</script>

<style scoped>
.container {
  padding: 40px ;
}


h1 {
  margin: 0 auto; 
  width: fit-content; 
}
</style>
