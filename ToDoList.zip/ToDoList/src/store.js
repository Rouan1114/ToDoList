import { createStore } from 'vuex';

export default createStore({
  state: {
    todos: [],
  },
  mutations: {
    ADD_TODO(state, todo) {
      state.todos.push(todo);
    },
    REMOVE_TODO(state, id) {
      state.todos = state.todos.filter(todo => todo.id !== id);
    },
    TOGGLE_TODO_COMPLETE(state, id) {
      const index = state.todos.findIndex(todo => todo.id === id);
      state.todos[index].completed = !state.todos[index].completed;
    },
    EDIT_TODO_TEXT(state, payload) {
      const index = state.todos.findIndex(todo => todo.id === payload.id);
      state.todos[index].text = payload.text;
    },
  },
  actions: {
    addTodoAsync({ commit }, todo) {
      commit('ADD_TODO', todo);
    },
    removeTodoAsync({ commit }, id) {
      commit('REMOVE_TODO', id);
    },
toggleTodoCompleteAsync(context, todo) {
    context.commit('TOGGLE_TODO_COMPLETE', todo);
  },
  
    editTodoAsync({ commit }, payload) {
      commit('EDIT_TODO_TEXT', payload);
    },
  },
  getters: {
    getTodos(state) {
      return state.todos;
    },
  },
});
