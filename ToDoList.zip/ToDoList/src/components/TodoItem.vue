<template>
    <li class="todo-item">
      <input type="checkbox" v-model="todo.completed" @change="toggleTodoComplete">
      <span @click="toggleEdit" :class="{ 'red-line': todo.completed && !editing }">{{ todo.text }}</span>
      <input v-if="editing" v-model="editedText" @keyup.enter="updateTodo" @blur="updateTodo">
      <div class="buttons-container">
        <button @click="removeTodo">刪除</button>
        <button @click="startEditing">編輯</button>
      </div>
    </li>
  </template>
  
  <script>
  export default {
    props: ['todo'],
    data() {
      return {
        editing: false,
        editedText: this.todo.text,
      };
    },
    methods: {
      removeTodo() {
        this.$emit('remove');
      },
      toggleTodoComplete() {
        this.$emit('toggle-complete', this.todo);
      },
      toggleEdit() {
        this.editing = !this.editing;
      },
      updateTodo() {
        if (this.editedText.trim() === '') {
          this.editing = false;
          return;
        }
        this.todo.text = this.editedText;
        this.editing = false;
        this.$emit('update', this.todo);
      },
      startEditing() {
        this.editedText = this.todo.text;
        this.editing = true;
      },
    },
  };
  </script>
  
  <style scoped>
  .todo-item {
    display: flex;
    align-items: center;
  }
  
  .buttons-container {
    margin-left: auto; 
    display: flex;
  }
  
  .red-line {
    text-decoration: line-through red; 
  }
  </style>
