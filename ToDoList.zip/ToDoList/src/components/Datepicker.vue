<template>
    <input type="date" v-model="selectedDate">
  </template>
  
  <script>
  export default {
    data() {
      return {
        selectedDate: null
      };
    }
  };
  </script>
  