<template>
    <div class="container">
      <input v-model="newTodo" @keyup.enter="addTodo" placeholder="新增待辦事項" class="input-field">
      <Datepicker v-model="selectedDate" placeholder="選擇日期" class="input-field"></Datepicker>
      <ul>
        <todo-item
          v-for="todo in todos"
          :key="todo.id"
          :todo="todo"
          @remove="removeTodo(todo.id)"
          @toggle-complete="toggleComplete(todo)"
          @edit="editTodoText(todo)"
          class="todo-item">
        </todo-item>
      </ul>
    </div>
  </template>
  
  <script>
  import { mapGetters, mapActions } from 'vuex';
  import Datepicker from './Datepicker.vue';
  import TodoItem from './TodoItem.vue';
  
  export default {
    components: {
      Datepicker,
      TodoItem,
    },
    data() {
      return {
        newTodo: '',
        selectedDate: null,
      };
    },
    computed: {
      ...mapGetters(['getTodos']),
      todos() {
        return this.getTodos.filter(todo => todo.date === this.selectedDate);
      },
    },
    methods: {
      ...mapActions(['addTodoAsync', 'removeTodoAsync', 'toggleTodoCompleteAsync', 'editTodoAsync']),
      addTodo() {
        if (this.newTodo.trim() && this.selectedDate) {
          const todo = {
            id: Math.floor(Math.random() * 1000), 
            text: this.newTodo.trim(),
            completed: false,
            date: this.selectedDate,
          };
          this.addTodoAsync(todo);
          this.newTodo = '';
        }
      },
      removeTodo(id) {
        this.removeTodoAsync(id);
      },
      toggleComplete(todo) {
        this.toggleTodoCompleteAsync(todo);
      },
      editTodoText(todo) {
        const index = this.getTodos.findIndex(t => t.id === todo.id);
        if (index !== -1) {
          this.getTodos[index].text = todo.text;
          this.editTodoAsync(todo);
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: #99c6ed; 
    border-radius: 5px;
  }
  
  .input-field {
    width: calc(100% - 40px);
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #115b78; 
    border-radius: 5px;
    font-family: 'Roboto', sans-serif;
  }
  
  ul {
    list-style-type: none;
    padding: 0;
  }
  
  .todo-item {
    background-color: #ffffff; 
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #87ceeb; 
    border-radius: 5px;
  }
  
  .todo-item:hover {
    background-color: #f0f8ff; 
  }
  </style>
  